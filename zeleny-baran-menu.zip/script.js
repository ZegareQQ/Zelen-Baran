function flipPage(page) {
  page.classList.toggle('flipped');
}
